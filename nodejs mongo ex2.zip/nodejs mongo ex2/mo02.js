var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:32452/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("studentNode");
  //Create a collection name "customers":
  dbo.createCollection("​studentmarksNode", function(err, res) {
    if (err) throw err;
    console.log("Collection created!");
    db.close();
  });
});
